<?php
/**
 * Elvis's own sausage recipes, from his Instagram reels (captions lightly tidied).
 * Each one has a photo at assets/photos/recipe-<slug>.webp.
 */
function kz_recipes() {
	return [
		[
			'slug' => 'dirty-cabbage', 'name' => 'Dirty Cabbage', 'tag' => 'One pot · 135K views', 'reel' => 'https://www.instagram.com/reel/DY4Tg9sK6D-/',
			'intro' => 'Sausage and beef, browned hard, then cabbage and carrot simmered in all that flavour. Cabbage will never be boring again.',
			'ingredients' => [ [ '1 large sausage', '1 kg beef', '1 onion', '3 garlic cloves', '1 tomato', '½ tbsp tomato paste', '1 large carrot', '¼ large cabbage', 'Soy sauce', '2 beef cubes', '½ tsp chilli flakes', '1 tsp salt', 'Chicken or beef stock', 'Oil' ] ],
			'method' => [
				'Get some oil properly hot in a pot. Brown the sausage first so it releases its flavour into the pan, then add the beef and brown that too.',
				'Add the onions, garlic and a splash of soy sauce and sauté together. Add the beef cubes, chilli flakes and salt, then the tomato and tomato paste. Cover and let the tomatoes soften.',
				'Add the carrot and cabbage, pour in the stock and simmer for 10 minutes. Dirty cabbage, ready for duty.',
			],
		],
		[
			'slug' => 'mango-banger', 'name' => 'Chilli Mango Banger', 'tag' => 'Hotdog', 'reel' => 'https://www.instagram.com/reel/DZKaABIK8ig/',
			'intro' => 'A big sausage in a toasted bun with crunchy coleslaw and a sweet-hot mango and pickle sauce.',
			'ingredients' => [
				'Hotdog' => [ '1 large sausage', 'Hotdog buns' ],
				'Chilli-mango sauce' => [ '½ mango, diced', '1 pickle, diced', 'Chilli flakes', 'Hot sauce', '1 tbsp mayo', '1 tbsp honey' ],
				'Coleslaw' => [ '¼ cabbage, finely sliced', '1 carrot, grated', 'Pinch of black pepper', 'Pinch of salt', '½ tsp sugar', '1 tbsp mayo' ],
			],
			'method' => [
				'Grill, pan-fry or air-fry the sausage until nicely browned and cooked through.',
				'Mix the mango, pickle, chilli flakes, hot sauce, mayo and honey. Set aside.',
				'Toss the cabbage, carrot, pepper, salt, sugar and mayo for the coleslaw.',
				'Toast the buns. Sausage in, a generous layer of coleslaw, then the mango sauce and an extra pinch of chilli.',
			],
		],
		[
			'slug' => 'pork-dry-fry', 'name' => 'Pork Belly & Sausage Dry Fry', 'tag' => 'With ugali', 'reel' => 'https://www.instagram.com/reel/Dc07aHyO1NY/',
			'intro' => 'Rendered pork belly and smoked sausage, glazed with soy, vinegar and honey. Serve with a mountain of ugali.',
			'ingredients' => [ [ 'Pork belly', 'Smoked sausages', 'Onions & garlic', '½ tsp black pepper', '1 tsp curry powder', '3 tbsp dark soy sauce', '4 tbsp vinegar', '3 tbsp honey', 'Carrots, julienned', 'Hoho (green pepper)', 'Fresh chilli', 'Ugali, with 2 tbsp margarine stirred in' ] ],
			'method' => [
				'Put the pork belly in a hot pot with a little water, cover and let it cook down while the fat renders.',
				'Add the smoked sausages and sauté until they start to brown. Add plenty of onion and garlic, then the black pepper and curry powder.',
				'Add the soy sauce, vinegar and honey and keep tossing as it cooks down.',
				'Finish with the carrots, hoho and a little fresh chilli, and toss until it all comes together.',
			],
		],
		[
			'slug' => 'bean-stew', 'name' => 'Sausage Bean Stew', 'tag' => 'Weeknight', 'reel' => 'https://www.instagram.com/reel/DZZvbkCug78/',
			'intro' => 'Browned sausages, a curried tomato base, beans and greens. Ten minutes of simmering, a whole lot of comfort.',
			'ingredients' => [ [ '2 large sausages', '1 large onion, diced', '3 garlic cloves, minced', '1 tbsp tomato paste', '1 large tomato, diced', '1 tbsp curry powder', '½ tsp black pepper', '1 tsp mixed spice', '1 beef cube', '½ tsp salt', 'Beans mix', '1 carrot, grated', '1 bell pepper, diced', 'Chicken stock', 'Sukuma or spinach', 'Fresh dhania', 'Water' ] ],
			'method' => [
				'Brown the sausages, then add the onion and garlic and cook until fragrant.',
				'Fry the tomato paste for a minute, add the tomato, cover and let it break down for 5 minutes.',
				'Stir in the curry powder, pepper, mixed spice, beef cube and salt.',
				'Add the beans, carrot, pepper, stock and greens, a little water, and simmer for 10 minutes. Finish with dhania.',
			],
		],
		[
			'slug' => 'pishori-stir-fry', 'name' => 'Chicken, Sausage & Pishori Stir-Fry', 'tag' => 'Fast fried rice', 'reel' => 'https://www.instagram.com/reel/Dd8yK4yuQJo/',
			'intro' => 'Yesterday\'s Pishori rice, chicken and sliced sausage, tossed hot with a sticky soy-vinegar sauce.',
			'ingredients' => [
				'Stir-fry' => [ '400 g chicken thighs, in strips', '2 large sausages, sliced', '2 large onions, sliced', '4 garlic cloves, minced', '1 tsp crushed ginger', 'Green & red pepper', 'Cooked Pishori rice (overnight is best)' ],
				'Spice mix' => [ '½ tsp black pepper', '1 tsp curry powder', '1 tsp paprika', '½ tbsp ginger powder', '2 beef cubes' ],
				'Sauce' => [ '4 tbsp soy sauce', '4 tbsp vinegar', '1 tbsp oyster sauce', '1 tbsp brown sugar' ],
			],
			'method' => [
				'Fry the chicken and sausage in hot oil until cooked and browned. Add the onions, garlic and ginger, then the spice mix.',
				'Add the peppers, oyster sauce, brown sugar and vinegar.',
				'Toss in the rice, add the soy sauce and stir-fry until everything is hot and coated.',
			],
		],
		[
			'slug' => 'loaded-fries', 'name' => 'Loaded Fries', 'tag' => 'Game night', 'reel' => 'https://www.instagram.com/reel/DWWHB8-DLrv/',
			'intro' => 'Crispy fries buried under sausage, bacon and beans, cheese sauce and a garlicky white sauce.',
			'ingredients' => [
				'Fries' => [ '2 large potatoes' ],
				'Topping' => [ 'Sausage, bacon, canned beans', 'Paprika, black pepper, chilli flakes', 'BBQ sauce or ketchup' ],
				'Cheese sauce' => [ 'Butter, milk, cheddar, mozzarella', 'Salt & pepper' ],
				'White sauce' => [ 'Mayo, garlic, chives', 'Lemon juice, salt & pepper' ],
			],
			'method' => [],
		],
	];
}
