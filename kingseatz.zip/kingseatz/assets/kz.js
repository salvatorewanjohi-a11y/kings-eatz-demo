( function () {
	const cfg = window.KZ || {};
	const packs = cfg.products || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s == null ? '' : s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const flames = ( n ) => '<span class="kz-heat" aria-hidden="true">' + [ 1, 2, 3 ].map( ( i ) => '<i' + ( i > n ? ' class="is-off"' : '' ) + '></i>' ).join( '' ) + '</span>';
	const HEAT = [ 'No heat', 'Gentle', 'Medium', 'Hot' ];
	const isStatic = () => !! window.KZ_STATIC;
	// wp_localize_script sends top-level numbers as strings.
	const DELIVERY = Number( cfg.delivery ) || 0;

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.kz-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'kz-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
		}
		// An open dialog sits in the top layer: show the toast inside it so it isn't hidden.
		const open = document.querySelector( 'dialog[open]' );
		if ( box.parentNode !== ( open || document.body ) ) ( open || document.body ).appendChild( box );
		const t = document.createElement( 'div' );
		t.className = 'kz-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3800 );
		setTimeout( () => t.remove(), 4300 );
	}
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your box · <a href="' + esc( cfg.checkout ) + '">Checkout</a>' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart; tell it to reload.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id, quantity ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity: quantity || 1 } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		await refreshMiniCart( cart );
		document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
		setTimeout( () => refreshMiniCart(), 900 );
		return cart;
	}
	const addedMsg = ( d, qty ) => '✓ ' + ( qty > 1 ? qty + ' × ' : '' ) + esc( d.name ) + ( d.batch.state === 'preorder' ? ' (pre-order)' : '' ) + ' added · <a href="' + esc( cfg.checkout ) + '">Checkout</a>';

	// Quick "Add": one pack.
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-kz-quick]' );
		if ( ! b ) return;
		e.preventDefault();
		const d = packs[ b.dataset.kzQuick ];
		if ( ! d ) return;
		const label = b.textContent;
		b.disabled = true;
		b.classList.add( 'is-busy' );
		try {
			await addItem( d.id, 1 );
			b.classList.add( 'is-done' );
			b.textContent = '✓';
			setTimeout( () => {
				b.classList.remove( 'is-done' );
				b.textContent = label;
			}, 1600 );
			toast( addedMsg( d, 1 ) );
		} catch ( err ) {
			toast( esc( err.message || 'Could not add. Please try again.' ) );
		} finally {
			b.disabled = false;
			b.classList.remove( 'is-busy' );
		}
	} );

	/* Pack pop-up -------------------------------------------------------- */
	const dlg = document.getElementById( 'kz-pack' );
	function openPack( id ) {
		const d = packs[ id ];
		if ( ! d || ! dlg || ! dlg.showModal ) return false;
		const body = dlg.querySelector( '[data-kz-pack-body]' );
		const imgs = d.imgs.length ? d.imgs : [ '' ];
		const pre = d.batch.state === 'preorder';
		let qty = 1;
		body.innerHTML =
			'<div class="kz-pack__grid">' +
			'<div class="kz-pack__media"><div class="kz-pack__main">' + imgs.map( ( src, i ) => '<img src="' + esc( src ) + '" alt="' + ( i ? '' : esc( d.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' ) +
			'<span class="kz-batch kz-batch--' + esc( d.batch.state ) + '"><i></i>' + esc( d.batch.label ) + '</span></div>' +
			'<div class="kz-pack__thumbs">' + imgs.map( ( src, i ) => '<button type="button" data-kz-img="' + i + '"' + ( i ? '' : ' class="is-on"' ) + '><img src="' + esc( src ) + '" alt=""></button>' ).join( '' ) + '</div></div>' +
			'<div class="kz-pack__info">' +
			'<p class="kz-eyebrow">' + esc( d.emoji + ' ' + d.tagline ) + '</p><h2>' + esc( d.name ) + '</h2>' +
			'<div class="kz-tags">' + ( d.badge ? '<span class="kz-tag">' + esc( d.badge ) + '</span>' : '' ) + '<span class="kz-tag kz-tag--line">800g+ · 9–10 sausages</span><span class="kz-tag kz-tag--line">' + flames( d.heat ) + ' ' + esc( HEAT[ d.heat ] ) + '</span></div>' +
			'<p class="kz-pack__desc">' + esc( d.short ) + '</p>' +
			( d.flavour ? '<p class="kz-pack__flavour"><strong>How it tastes:</strong> ' + esc( d.flavour ) + '</p>' : '' ) +
			'<ul class="kz-pack__facts"><li>🥩 100% meat, no fillers</li><li>🔥 Smoked in our own smokehouse</li><li>❄️ Vacuum-sealed: fridge or freezer</li>' + ( d.pairs.length ? '<li>🍽 Great with ' + esc( d.pairs.join( ', ' ).toLowerCase() ) + '</li>' : '' ) + '</ul>' +
			( pre ? '<p class="kz-alert">This batch is sold out. Order now and your packs come from the <strong>' + esc( cfg.batch.label ) + '</strong> batch.</p>' : '' ) +
			'<div class="kz-pack__buy"><div class="kz-qty"><button type="button" data-kz-q="-1" aria-label="One pack less">−</button><output data-kz-q-out>1</output><button type="button" data-kz-q="1" aria-label="One pack more">+</button></div>' +
			'<button type="button" class="wp-element-button kz-pack__add" data-kz-pack-add>' + ( pre ? 'Pre-order' : 'Add to box' ) + ' · <span data-kz-q-total></span></button></div>' +
			'<div class="kz-pack__links"><button type="button" class="kz-form-btn" data-kz-order="' + d.id + '">Order with the quick form</button>' + ( d.reel ? '<a class="kz-link" href="' + esc( d.reel ) + '" target="_blank" rel="noopener">▶ See them made</a>' : '' ) + '<a class="kz-link" href="' + esc( d.url ) + '">Full details →</a></div>' +
			'</div></div>';
		const paint = () => {
			body.querySelector( '[data-kz-q-out]' ).textContent = qty;
			body.querySelector( '[data-kz-q-total]' ).textContent = fmt( d.price * qty );
		};
		body.onclick = async ( e ) => {
			const q = e.target.closest( '[data-kz-q]' );
			if ( q ) {
				qty = Math.max( 1, Math.min( 20, qty + Number( q.dataset.kzQ ) ) );
				paint();
			}
			const ti = e.target.closest( '[data-kz-img]' );
			if ( ti ) {
				$$( '.kz-pack__main img', body ).forEach( ( im, i ) => ( im.hidden = i !== Number( ti.dataset.kzImg ) ) );
				$$( '.kz-pack__thumbs button', body ).forEach( ( b ) => b.classList.toggle( 'is-on', b === ti ) );
			}
			const add = e.target.closest( '[data-kz-pack-add]' );
			if ( add ) {
				add.disabled = true;
				try {
					await addItem( d.id, qty );
					dlg.close();
					toast( addedMsg( d, qty ) );
				} catch ( err ) {
					toast( esc( err.message || 'Could not add. Please try again.' ) );
				} finally {
					add.disabled = false;
				}
			}
		};
		paint();
		dlg.showModal();
		return true;
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-kz-pack]' );
		if ( ! b || e.ctrlKey || e.metaKey || e.shiftKey ) return;
		if ( openPack( b.dataset.kzPack ) ) e.preventDefault();
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.kz-dialog' ) ) e.target.close();
	} );

	/* Shop: flavour filter ------------------------------------------------ */
	document.addEventListener( 'click', ( e ) => {
		const c = e.target.closest( '[data-kz-filter]' );
		if ( ! c ) return;
		const shop = c.closest( '[data-kz-shop]' );
		const tag = c.dataset.kzFilter;
		$$( '[data-kz-filter]', shop ).forEach( ( x ) => x.classList.toggle( 'is-on', x === c ) );
		$$( '[data-kz-card]', shop ).forEach( ( card ) => ( card.hidden = !! tag && card.dataset.tags.split( ' ' ).indexOf( tag ) === -1 ) );
	} );

	/* Build your box ------------------------------------------------------ */
	function initBox() {
		const box = document.querySelector( '[data-kz-box]' );
		if ( ! box ) return;
		const qty = {};
		const rows = $$( '[data-kz-box-row]', box );
		const paint = () => {
			let n = 0, total = 0;
			rows.forEach( ( r ) => {
				const id = r.dataset.kzBoxRow;
				r.querySelector( '[data-kz-box-qty]' ).textContent = qty[ id ] || 0;
				r.classList.toggle( 'is-on', ( qty[ id ] || 0 ) > 0 );
				n += qty[ id ] || 0;
				total += ( qty[ id ] || 0 ) * ( packs[ id ] ? packs[ id ].price : 0 );
			} );
			box.querySelector( '[data-kz-box-count]' ).textContent = n ? n + ( n === 1 ? ' pack' : ' packs' ) + ' · ' + n * 9 + '+ sausages' : 'No packs yet';
			box.querySelector( '[data-kz-box-total]' ).textContent = fmt( total + ( n ? DELIVERY : 0 ) );
			box.querySelector( '[data-kz-box-note]' ).textContent = n ? 'Packs ' + fmt( total ) + ' + ' + fmt( DELIVERY ) + ' delivery' : '+ ' + fmt( DELIVERY ) + ' delivery';
			$$( '[data-kz-box-add],[data-kz-box-form]', box ).forEach( ( b ) => ( b.disabled = ! n ) );
		};
		box.addEventListener( 'click', async ( e ) => {
			const s = e.target.closest( '[data-kz-box-step]' );
			if ( s ) {
				const id = s.closest( '[data-kz-box-row]' ).dataset.kzBoxRow;
				qty[ id ] = Math.max( 0, Math.min( 20, ( qty[ id ] || 0 ) + Number( s.dataset.kzBoxStep ) ) );
				paint();
			}
			const add = e.target.closest( '[data-kz-box-add]' );
			if ( add ) {
				add.disabled = true;
				add.textContent = 'Adding…';
				try {
					for ( const id of Object.keys( qty ) ) if ( qty[ id ] ) await addItem( id, qty[ id ] );
					location.href = cfg.checkout;
				} catch ( err ) {
					toast( esc( err.message || 'Could not add. Please try again.' ) );
					add.disabled = false;
					add.textContent = 'Add box & check out';
				}
			}
			if ( e.target.closest( '[data-kz-box-form]' ) ) openOrderForm( qty );
		} );
		paint();
	}
	// Recipe and promo links: jump to the box (when it is on the page) and pulse it.
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-kz-box-link]' );
		const box = document.querySelector( '[data-kz-box]' );
		if ( ! a || ! box ) return;
		e.preventDefault();
		box.scrollIntoView( { behavior: 'smooth', block: 'center' } );
		box.classList.remove( 'is-ping' );
		void box.offsetWidth;
		box.classList.add( 'is-ping' );
	} );

	/* Quick order form ---------------------------------------------------- */
	const orderDlg = document.getElementById( 'kz-order' );
	function initOrderForm( form ) {
		const qty = {};
		const paint = () => {
			let n = 0, total = 0;
			$$( '[data-kz-of-pack]', form ).forEach( ( row ) => {
				const id = row.dataset.kzOfPack;
				const q = qty[ id ] || 0;
				row.querySelector( '[data-kz-of-qty]' ).textContent = q;
				row.querySelector( 'input[type=hidden]' ).value = q;
				row.classList.toggle( 'is-on', q > 0 );
				n += q;
				total += q * ( packs[ id ] ? packs[ id ].price : 0 );
			} );
			form.querySelector( '[data-kz-of-count]' ).textContent = n ? n + ( n === 1 ? ' pack' : ' packs' ) + ' + delivery' : 'Add at least one pack';
			form.querySelector( '[data-kz-of-total]' ).textContent = fmt( total + ( n ? DELIVERY : 0 ) );
			$$( '.kz-pills label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
			return n;
		};
		form.kzSet = ( preset ) => {
			Object.keys( qty ).forEach( ( k ) => delete qty[ k ] );
			Object.assign( qty, preset || {} );
			paint();
		};
		form.addEventListener( 'click', ( e ) => {
			const s = e.target.closest( '[data-kz-of-step]' );
			if ( ! s ) return;
			const id = s.closest( '[data-kz-of-pack]' ).dataset.kzOfPack;
			qty[ id ] = Math.max( 0, Math.min( 20, ( qty[ id ] || 0 ) + Number( s.dataset.kzOfStep ) ) );
			paint();
		} );
		form.addEventListener( 'change', paint );
		form.addEventListener( 'submit', async ( e ) => {
			e.preventDefault();
			if ( ! paint() ) {
				toast( 'Add at least one pack.' );
				return;
			}
			if ( ! form.reportValidity() ) return;
			const fd = new FormData( form );
			if ( isStatic() ) {
				const url = googleFormUrl( form, fd, qty );
				// Opened inside the click so pop-up blockers allow it.
				if ( ! window.open( url, '_blank', 'noopener' ) ) location.href = url;
				done( form, '<h3>Almost done!</h3><p>Our order form just opened in a new tab with everything filled in. <strong>Tap Submit there</strong> and your order is in.</p><p class="kz-small">Didn\'t open? <a href="' + esc( url ) + '" target="_blank" rel="noopener">Open the order form</a>.</p>' );
				return;
			}
			const go = form.querySelector( '[data-kz-of-go]' );
			go.disabled = true;
			go.textContent = 'Placing your order…';
			try {
				const body = { packs: qty };
				fd.forEach( ( v, k ) => {
					if ( ! k.startsWith( 'packs[' ) ) body[ k ] = v;
				} );
				const res = await fetch( cfg.api + 'order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( body ) } );
				const j = await res.json();
				if ( ! res.ok ) throw new Error( j.message || 'Could not place the order.' );
				done( form, '<h3>Order placed! 🔥</h3><p class="kz-thanks__code">Order number <strong>' + esc( j.code ) + '</strong></p><p class="kz-thanks__when">' + esc( j.total ) + ' · delivery ' + esc( j.when ) + '</p>' + ( j.pre ? '<p>Some packs are pre-orders: they come from the next batch.</p>' : '' ) + '<ol><li>We call or text ' + esc( fd.get( 'phone' ) ) + ' to confirm the day.</li><li>Your packs arrive vacuum-sealed.</li><li>Pay the rider by M-Pesa or cash.</li></ol>' );
			} catch ( err ) {
				toast( esc( err.message ) );
			} finally {
				go.disabled = false;
				go.textContent = 'Place my order';
			}
		} );
		paint();
	}
	function done( form, html ) {
		const box = document.createElement( 'div' );
		box.className = 'kz-thanks';
		box.innerHTML = html + '<button type="button" class="kz-link-btn" data-kz-again>Place another order</button>';
		form.hidden = true;
		form.after( box );
		box.querySelector( '[data-kz-again]' ).addEventListener( 'click', () => {
			box.remove();
			form.reset();
			form.kzSet( {} );
			form.hidden = false;
		} );
	}
	// The static copy has no server: Elvis's own Google Form, pre-filled, takes the order.
	function googleFormUrl( form, fd, qty ) {
		const g = cfg.gfields;
		const text = ( name ) => {
			const el = form.elements[ name ];
			return el && el.tagName === 'SELECT' ? el.selectedOptions[ 0 ].text : String( fd.get( name ) || '' );
		};
		const p = new URLSearchParams( { usp: 'pp_url' } );
		p.set( g.name, text( 'name' ) );
		p.set( g.phone, text( 'phone' ) );
		p.set( g.location, text( 'location' ) );
		const extra = [];
		Object.keys( qty ).forEach( ( id ) => {
			const d = packs[ id ];
			const n = Math.min( 5, qty[ id ] || 0 ); // his form goes up to 5 packs per flavour
			if ( ! d || ! n ) return;
			if ( g.packs[ d.slug ] ) p.set( g.packs[ d.slug ], n + ( n === 1 ? ' Pack' : ' Packs' ) );
			if ( qty[ id ] > 5 ) extra.push( d.name + ': ' + qty[ id ] + ' packs' );
		} );
		const notes = [ 'Delivery ' + text( 'day' ) + ', ' + text( 'time' ), text( 'pay' ) === 'bacs' ? 'Paying ahead by M-Pesa' : 'Pay on delivery', ...extra, text( 'notes' ) ].filter( Boolean ).join( ' · ' );
		p.set( g.notes, notes + ' (via the website)' );
		return cfg.gform + '?' + p.toString();
	}
	function openOrderForm( preset ) {
		if ( ! orderDlg || ! orderDlg.showModal ) {
			location.href = cfg.shop + '#box';
			return;
		}
		if ( dlg && dlg.open ) dlg.close();
		const form = orderDlg.querySelector( '[data-kz-order-form]' );
		if ( form && ! form.hidden ) form.kzSet( { ...( preset || {} ) } );
		orderDlg.showModal();
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-kz-order]' );
		if ( ! b ) return;
		e.preventDefault();
		const id = b.dataset.kzOrder;
		openOrderForm( id && packs[ id ] ? { [ id ]: 1 } : {} );
	} );

	/* Party orders & Carnivore Club --------------------------------------- */
	function initRequests() {
		$$( '[data-kz-request]' ).forEach( ( form ) => {
			form.addEventListener( 'submit', async ( e ) => {
				e.preventDefault();
				if ( ! form.reportValidity() ) return;
				const type = form.dataset.kzRequest;
				const fd = new FormData( form );
				const btn = form.querySelector( '[type=submit]' );
				const label = btn.textContent;
				if ( isStatic() ) {
					if ( type === 'club' ) {
						// No list to join on the static copy: new flavours are announced on Instagram first.
						window.open( cfg.ig, '_blank', 'noopener' );
						toast( '🔥 New flavours drop on Instagram first: follow @kings_eatz.' );
						return;
					}
					// Party orders go into his order form too, with the details in the notes.
					const g = cfg.gfields;
					const txt = ( k ) => {
						const el = form.elements[ k ];
						return el && el.tagName === 'SELECT' ? el.selectedOptions[ 0 ].text : String( fd.get( k ) || '' );
					};
					const p = new URLSearchParams( { usp: 'pp_url' } );
					p.set( g.name, txt( 'name' ) );
					p.set( g.phone, txt( 'phone' ) );
					p.set( g.location, txt( 'location' ) || 'Party order' );
					p.set( g.notes, 'PARTY ORDER: ' + txt( 'occasion' ) + ', ' + txt( 'date' ) + ', ' + txt( 'guests' ) + ' guests, ' + txt( 'packs' ) + ', ' + txt( 'flavours' ) + ( txt( 'notes' ) ? '. ' + txt( 'notes' ) : '' ) + ' (via the website)' );
					window.open( cfg.gform + '?' + p.toString(), '_blank', 'noopener' );
					toast( 'Your party order is filled in on our order form: <strong>tap Submit there</strong>.' );
					return;
				}
				const body = { type };
				fd.forEach( ( v, k ) => ( body[ k ] = v ) );
				btn.disabled = true;
				btn.textContent = 'Sending…';
				try {
					const res = await fetch( cfg.api + 'request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( body ) } );
					const j = await res.json();
					if ( ! res.ok ) throw new Error( j.message || 'Could not send.' );
					toast( type === 'club' ? '🔥 You\'re in the Carnivore Club. New flavours and batch drops come to you first.' : '✓ Party request <strong>' + esc( j.ref ) + '</strong> sent. We reply with dates and a total.' );
					form.reset();
				} catch ( err ) {
					toast( esc( err.message ) );
				} finally {
					btn.disabled = false;
					btn.textContent = label;
				}
			} );
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-kz-club-link]' );
		const club = document.getElementById( 'club' );
		if ( ! a || ! club ) return;
		e.preventDefault();
		club.scrollIntoView( { behavior: 'smooth', block: 'center' } );
		setTimeout( () => club.querySelector( 'input' ) && club.querySelector( 'input' ).focus( { preventScroll: true } ), 600 );
	} );

	/* Card photo sliders: dots follow the swipe -------------------------- */
	function initSlides() {
		$$( '.kz-card__slides' ).forEach( ( s ) => {
			const dots = $$( 'i', s.parentNode.querySelector( '.kz-card__dots' ) || document.createElement( 'div' ) );
			if ( ! dots.length ) return;
			dots[ 0 ].classList.add( 'is-on' );
			s.addEventListener( 'scroll', () => {
				const i = Math.round( s.scrollLeft / s.clientWidth );
				dots.forEach( ( d, n ) => d.classList.toggle( 'is-on', n === i ) );
			}, { passive: true } );
		} );
	}

	// The sticky header slides up by the announcement bar's height, whatever it wraps to.
	function measureAnnounce() {
		const a = document.querySelector( '.kz-announce' );
		if ( a ) document.documentElement.style.setProperty( '--kz-ann', a.offsetHeight + 'px' );
	}
	// Header menu: underline the page you're on.
	function markNav() {
		const here = location.pathname;
		const home = new URL( cfg.home || '/', location.href ).pathname;
		$$( '.kz-nav a.wp-block-navigation-item__content' ).forEach( ( a ) => {
			const path = new URL( a.href, location.href ).pathname;
			if ( path === home ? here === home : here.startsWith( path ) ) a.setAttribute( 'aria-current', 'page' );
		} );
	}
	// Kitchen clips only play while on screen (and never with reduced motion).
	function initClips() {
		const vids = $$( 'video[data-kz-clip]' );
		if ( ! vids.length || ! ( 'IntersectionObserver' in window ) ) return;
		if ( window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) return;
		const io = new IntersectionObserver( ( entries ) => entries.forEach( ( en ) => ( en.isIntersecting ? en.target.play().catch( () => {} ) : en.target.pause() ) ), { threshold: 0.2 } );
		vids.forEach( ( v ) => io.observe( v ) );
	}

	function init() {
		markNav();
		measureAnnounce();
		window.addEventListener( 'resize', measureAnnounce );
		window.addEventListener( 'load', measureAnnounce );
		initBox();
		$$( '[data-kz-order-form]' ).forEach( initOrderForm );
		initRequests();
		initSlides();
		initClips();
		// ?form=1 or #order-form opens the quick order form.
		if ( /[?&]form=1/.test( location.search ) || location.hash === '#order-form' ) setTimeout( () => openOrderForm( {} ), 300 );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
