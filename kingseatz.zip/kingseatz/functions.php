<?php
/**
 * Perfect Bite by Kings Eatz: a small-batch smoked sausage shop.
 * The packs are WooCommerce products with managed stock: each batch has a count, the shop shows what's
 * left, and a sold-out pack takes pre-orders for the next batch (backorders "notify").
 * Two ways to order: the cart + checkout, or the one-screen order form ([kz_order_form]), which creates
 * a real WooCommerce order. The static Vercel copy sends that form to Elvis's own Google Form instead.
 */

const KZ_IG       = 'https://www.instagram.com/kings_eatz/';
const KZ_TIKTOK   = 'https://www.tiktok.com/@perfectbite00';
const KZ_DELIVERY = 200; // KSh, anywhere in Nairobi (his order form)
const KZ_FONTS    = 'https://fonts.googleapis.com/css2?family=Anton&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,500&display=swap';

// His Google Form (bio link). The static copy pre-fills it; entry ids read from the live form on 13 Oct 2026.
const KZ_GFORM        = 'https://docs.google.com/forms/d/e/1FAIpQLSdd7RWtDvq1bDaavMUVP5uRY4MPmknHjBW3Xa_l-XKsolBvQg/viewform';
const KZ_GFORM_FIELDS = [
	'name'     => 'entry.1698145584',
	'phone'    => 'entry.555780399',
	'location' => 'entry.2065226506',
	'notes'    => 'entry.1770021278',
	'packs'    => [ 'chilli-honey-heat' => 'entry.851983067', 'cheese-onion-sausage' => 'entry.1842149709', 'classic-sausage' => 'entry.1684364789' ],
];

const KZ_HEAT  = [ 0 => 'No heat', 1 => 'Gentle', 2 => 'Medium', 3 => 'Hot' ];
const KZ_TIMES = [ 'morning' => 'Morning (9 am – 12 pm)', 'afternoon' => 'Afternoon (12 – 4 pm)', 'evening' => 'Evening (4 – 7 pm)' ]; // PLACEHOLDER windows
const KZ_DAYS  = [ 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday' ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'kz-fonts', KZ_FONTS, [], null );
	wp_enqueue_style( 'kz', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'kz', $uri . '/assets/kz.js', [], filemtime( $dir . '/assets/kz.js' ), true );
	wp_localize_script( 'kz', 'KZ', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'api'      => esc_url_raw( rest_url( 'kz/v1/' ) ),
		'shop'     => esc_url_raw( home_url( '/order/' ) ),
		'cart'     => esc_url_raw( wc_get_cart_url() ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'ig'       => KZ_IG,
		'delivery' => KZ_DELIVERY,
		'gform'    => KZ_GFORM,
		'gfields'  => KZ_GFORM_FIELDS,
		'batch'    => kz_next_batch(),
		'products' => kz_products(),
	] );
} );

add_action( 'enqueue_block_editor_assets', fn() => wp_enqueue_style( 'kz-fonts', KZ_FONTS, [], null ) );
add_action( 'after_setup_theme', fn() => add_editor_style( 'style.css' ) );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function kz_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}
function kz_lines( $product_id, $key ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_kz_' . $key, true ) ) ) ) );
}
function kz_flames( $n, $of = 3 ) {
	$h = '<span class="kz-heat" aria-label="Heat: ' . esc_attr( KZ_HEAT[ $n ] ?? '' ) . '">';
	for ( $i = 1; $i <= $of; $i++ ) {
		$h .= '<i' . ( $i > $n ? ' class="is-off"' : '' ) . '></i>';
	}
	return $h . '</span>';
}

const KZ_IG_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M12 2.2c3.2 0 3.6 0 4.8.1 3.3.1 4.8 1.7 4.9 4.9.1 1.3.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 3.2-1.7 4.8-4.9 4.9-1.3.1-1.6.1-4.8.1s-3.6 0-4.8-.1c-3.3-.1-4.8-1.7-4.9-4.9C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.8C2.4 3.9 3.9 2.4 7.2 2.3 8.4 2.2 8.8 2.2 12 2.2Zm0 4.9a4.9 4.9 0 1 0 0 9.8 4.9 4.9 0 0 0 0-9.8Zm0 8.1a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4Zm5.1-9.4a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4Z"/></svg>';
const KZ_TT_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M16.6 2h-3.3v13.4a2.9 2.9 0 1 1-2.9-2.9c.3 0 .6 0 .9.1V9.2a6.3 6.3 0 1 0 5.3 6.2V8.6a8 8 0 0 0 4.4 1.3V6.6a4.5 4.5 0 0 1-4.4-4.6Z"/></svg>';
const KZ_FORM_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M9 4h6m-6 0a1 1 0 0 0-1 1v1h8V5a1 1 0 0 0-1-1M9 4H7a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2M8.5 12.5l2 2 4-4.5"/></svg>';

/* -------------------------------------------------------------------------
 * Batches: the next batch day, and each pack's status in the current batch
 * ---------------------------------------------------------------------- */

/** The next batch day (WooCommerce → Batch drops), e.g. [ 'date' => '2026-10-16', 'label' => 'Fri 16 Oct' ]. */
function kz_next_batch() {
	$want = max( 1, min( 7, (int) get_option( 'kz_batch_day', 5 ) ) );
	$day  = new DateTime( 'tomorrow', wp_timezone() );
	while ( (int) $day->format( 'N' ) !== $want ) {
		$day->modify( '+1 day' );
	}
	return [ 'date' => $day->format( 'Y-m-d' ), 'label' => $day->format( 'D j M' ), 'day' => KZ_DAYS[ $want ], 'note' => (string) get_option( 'kz_batch_note', '' ) ];
}

/** fresh: plenty left · low: a few packs left · preorder: sold out, orders go into the next batch. */
function kz_batch_status( WC_Product $p ) {
	$qty = $p->managing_stock() ? (int) $p->get_stock_quantity() : null;
	$low = (int) ( $p->get_low_stock_amount() ?: 8 );
	if ( $qty !== null && $qty <= 0 ) {
		return [ 'state' => 'preorder', 'qty' => 0, 'label' => 'Sold out · pre-order for ' . kz_next_batch()['label'] ];
	}
	if ( ! $p->is_in_stock() ) {
		return [ 'state' => 'out', 'qty' => 0, 'label' => 'Sold out' ];
	}
	if ( $qty !== null && $qty <= $low ) {
		return [ 'state' => 'low', 'qty' => $qty, 'label' => 'Only ' . $qty . ' pack' . ( $qty === 1 ? '' : 's' ) . ' left this batch' ];
	}
	return [ 'state' => 'fresh', 'qty' => $qty, 'label' => 'Fresh batch in stock' ];
}

/* -------------------------------------------------------------------------
 * Pack data (one list for the shop, the pop-up, the order form and the cart)
 * ---------------------------------------------------------------------- */

function kz_products() {
	static $out = null;
	if ( $out !== null ) {
		return $out;
	}
	$out = [];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] ) as $p ) {
		if ( ! $p->is_type( 'simple' ) ) continue;
		$id   = $p->get_id();
		$imgs = [];
		foreach ( array_merge( [ $p->get_image_id() ], $p->get_gallery_image_ids() ) as $aid ) {
			$src = $aid ? wp_get_attachment_image_url( $aid, 'woocommerce_single' ) : '';
			if ( $src ) $imgs[] = $src;
		}
		$out[ $id ] = [
			'id'      => $id,
			'slug'    => $p->get_slug(),
			'name'    => $p->get_name(),
			'price'   => (float) $p->get_price(),
			'heat'    => (int) get_post_meta( $id, '_kz_heat', true ),
			'tagline' => get_post_meta( $id, '_kz_tagline', true ),
			'emoji'   => get_post_meta( $id, '_kz_emoji', true ),
			'badge'   => get_post_meta( $id, '_kz_badge', true ),
			'flavour' => get_post_meta( $id, '_kz_flavour', true ),
			'pairs'   => kz_lines( $id, 'pairs' ),
			'reel'    => get_post_meta( $id, '_kz_reel', true ),
			'tags'    => wp_get_post_terms( $id, 'product_tag', [ 'fields' => 'slugs' ] ),
			'short'   => wp_strip_all_tags( $p->get_short_description() ),
			'batch'   => kz_batch_status( $p ),
			'buyable' => $p->is_purchasable() && ( $p->is_in_stock() || $p->backorders_allowed() ),
			'imgs'    => $imgs,
			'url'     => get_permalink( $id ),
			'order'   => $p->get_menu_order(),
		];
	}
	return $out;
}

const KZ_PACK = '800g+ · 9–10 sausages';

/* -------------------------------------------------------------------------
 * Shop: [kz_shop] = pack cards + "build your box"
 * ---------------------------------------------------------------------- */

function kz_card( array $d ) {
	$slides = '';
	foreach ( $d['imgs'] ?: [ '' ] as $i => $src ) {
		$slides .= '<img src="' . esc_url( $src ) . '" alt="' . ( $i ? '' : esc_attr( $d['name'] ) ) . '" loading="lazy" width="720" height="720">';
	}
	$dots = count( $d['imgs'] ) > 1 ? '<span class="kz-card__dots">' . str_repeat( '<i></i>', count( $d['imgs'] ) ) . '</span>' : '';
	$b    = $d['batch'];
	return sprintf(
		'<article class="kz-card is-%13$s" data-kz-card data-id="%1$d" data-slug="%2$s" data-tags="%3$s" data-price="%4$d">
			<div class="kz-card__media"><a class="kz-card__slides" href="%5$s" data-kz-pack="%1$d" aria-label="%6$s">%7$s</a>%8$s%9$s
				<span class="kz-batch kz-batch--%13$s" data-kz-batch="%1$d"><i></i>%14$s</span></div>
			<div class="kz-card__body">
				<p class="kz-card__tag">%10$s %11$s</p>
				<h3 class="kz-card__title"><a href="%5$s" data-kz-pack="%1$d">%6$s</a></h3>
				<p class="kz-card__short">%12$s</p>
				<div class="kz-card__metas"><span class="kz-meta">%15$s</span><span class="kz-meta kz-meta--heat">%16$s %17$s</span></div>
				<div class="kz-card__foot">
					<p class="kz-card__price">%18$s<small> / pack</small></p>
					<div class="kz-card__actions">
						<button type="button" class="kz-btn-line" data-kz-pack="%1$d">Details</button>
						<button type="button" class="kz-btn-add" data-kz-quick="%1$d" aria-label="Add a pack of %6$s to your box">%19$s</button>
					</div>
				</div>
			</div>
		</article>',
		$d['id'],
		esc_attr( $d['slug'] ),
		esc_attr( implode( ' ', $d['tags'] ) ),
		(int) $d['price'],
		esc_url( $d['url'] ),
		esc_attr( $d['name'] ),
		$slides,
		$dots,
		$d['badge'] ? '<span class="kz-card__badge">' . esc_html( $d['badge'] ) . '</span>' : '',
		esc_html( $d['emoji'] ),
		esc_html( $d['tagline'] ),
		esc_html( $d['short'] ),
		esc_attr( $d['batch']['state'] ),
		esc_html( $b['label'] ),
		esc_html( KZ_PACK ),
		kz_flames( $d['heat'] ),
		esc_html( KZ_HEAT[ $d['heat'] ] ?? '' ),
		esc_html( kz_money( $d['price'] ) ),
		$b['state'] === 'preorder' ? 'Pre-order' : 'Add'
	);
}

add_shortcode( 'kz_shop', function () {
	$packs = kz_products();
	$batch = kz_next_batch();
	$cards = '';
	foreach ( $packs as $d ) {
		$cards .= kz_card( $d );
	}
	// The flavour Elvis asked his followers about (Day 3 reel): not on sale, a drop alert.
	$cards .= '<article class="kz-card kz-card--next"><div class="kz-next"><p class="kz-eyebrow">In the lab</p><h3>Loaded Cheese?</h3><p>"Should I make a loaded cheese version?" Elvis asked on Day 3, and the comments said yes. Join the Carnivore Club and you hear first when a new flavour drops.</p><a class="kz-link" href="#club" data-kz-club-link>Get the drop alert →</a></div></article>';

	$rows = '';
	foreach ( $packs as $d ) {
		$rows .= '<div class="kz-box__row" data-kz-box-row="' . (int) $d['id'] . '"><div class="kz-box__name"><img src="' . esc_url( $d['imgs'][0] ?? '' ) . '" alt="" width="48" height="48" loading="lazy"><span><strong>' . esc_html( $d['name'] ) . '</strong><small>' . esc_html( kz_money( $d['price'] ) ) . ' · <em data-kz-box-state>' . esc_html( $d['batch']['state'] === 'preorder' ? 'pre-order' : ( $d['batch']['state'] === 'low' ? $d['batch']['qty'] . ' left' : 'in stock' ) ) . '</em></small></span></div>'
			. '<div class="kz-qty"><button type="button" data-kz-box-step="-1" aria-label="One pack less of ' . esc_attr( $d['name'] ) . '">−</button><output data-kz-box-qty>0</output><button type="button" data-kz-box-step="1" aria-label="One pack more of ' . esc_attr( $d['name'] ) . '">+</button></div></div>';
	}

	ob_start();
	?>
	<div class="kz-shop" data-kz-shop>
		<div class="kz-shop__bar">
			<div class="kz-chips" role="group" aria-label="Filter by flavour">
				<button type="button" class="kz-chip is-on" data-kz-filter="">All flavours</button>
				<button type="button" class="kz-chip" data-kz-filter="spicy">🌶️ Spicy</button>
				<button type="button" class="kz-chip" data-kz-filter="cheesy">🧀 Cheesy</button>
				<button type="button" class="kz-chip" data-kz-filter="original">🌭 The original</button>
			</div>
			<p class="kz-shop__next">🔥 Next batch: <strong><?php echo esc_html( $batch['label'] ); ?></strong></p>
		</div>
		<div class="kz-grid" data-kz-grid><?php echo $cards; // phpcs:ignore ?></div>

		<section class="kz-box" id="box" data-kz-box aria-labelledby="kz-box-title">
			<div class="kz-box__intro">
				<p class="kz-eyebrow">Build your box</p>
				<h3 id="kz-box-title">Mix your flavours</h3>
				<p>Pick how many packs of each. Delivery is <?php echo esc_html( kz_money( KZ_DELIVERY ) ); ?> anywhere in Nairobi, whatever the size of your box.</p>
				<ul class="kz-box__facts"><li>Every pack: <?php echo esc_html( KZ_PACK ); ?></li><li>Vacuum-sealed, keeps in the fridge or freezer</li><li>Pay on delivery, M-Pesa or cash</li></ul>
			</div>
			<div class="kz-box__panel">
				<?php echo $rows; // phpcs:ignore ?>
				<div class="kz-box__total"><span data-kz-box-count>No packs yet</span><strong data-kz-box-total>KSh 0</strong></div>
				<p class="kz-box__note" data-kz-box-note>+ <?php echo esc_html( kz_money( KZ_DELIVERY ) ); ?> delivery</p>
				<div class="kz-box__go">
					<button type="button" class="wp-element-button" data-kz-box-add disabled>Add box &amp; check out</button>
					<button type="button" class="wp-element-button kz-btn-ghost" data-kz-box-form disabled><?php echo KZ_FORM_ICON; // phpcs:ignore ?>Use the quick order form</button>
				</div>
			</div>
		</section>
	</div>
	<?php
	return ob_get_clean();
} );

// Live batch status for the hero: one line per pack.
add_shortcode( 'kz_batch', function () {
	$batch = kz_next_batch();
	$h     = '<div class="kz-batchcard"><p class="kz-batchcard__title"><span class="kz-live"></span>This batch</p><ul>';
	foreach ( kz_products() as $d ) {
		$b  = $d['batch'];
		$h .= '<li class="is-' . esc_attr( $b['state'] ) . '"><span>' . esc_html( $d['emoji'] . ' ' . $d['name'] ) . '</span><b data-kz-batch="' . (int) $d['id'] . '">' . esc_html( $b['state'] === 'fresh' ? 'In stock' : ( $b['state'] === 'low' ? $b['qty'] . ' left' : 'Pre-order' ) ) . '</b></li>';
	}
	return $h . '</ul><p class="kz-batchcard__next">Next fresh batch <strong>' . esc_html( $batch['label'] ) . '</strong></p></div>';
} );

/* -------------------------------------------------------------------------
 * The quick order form: one screen, like his Google Form, but it makes a real order
 * ---------------------------------------------------------------------- */

/** Delivery days for the next week: Y-m-d => "Fri 16 Oct". */
function kz_dates( $days = 7 ) {
	$out = [];
	$day = new DateTime( 'tomorrow', wp_timezone() );
	for ( $i = 0; $i < $days; $i++ ) {
		$out[ $day->format( 'Y-m-d' ) ] = ( $i === 0 ? 'Tomorrow, ' : '' ) . $day->format( 'D j M' );
		$day->modify( '+1 day' );
	}
	return $out;
}

function kz_order_form() {
	$rows = '';
	foreach ( kz_products() as $d ) {
		$rows .= '<div class="kz-of__pack" data-kz-of-pack="' . (int) $d['id'] . '"><img src="' . esc_url( $d['imgs'][0] ?? '' ) . '" alt="" width="56" height="56" loading="lazy"><span class="kz-of__packname"><strong>' . esc_html( $d['name'] ) . '</strong><small>' . esc_html( kz_money( $d['price'] ) ) . ' · ' . esc_html( $d['batch']['state'] === 'preorder' ? 'pre-order, next batch' : ( $d['batch']['state'] === 'low' ? 'only ' . $d['batch']['qty'] . ' left' : 'in stock' ) ) . '</small></span>'
			. '<div class="kz-qty"><button type="button" data-kz-of-step="-1" aria-label="One pack less">−</button><output data-kz-of-qty>0</output><button type="button" data-kz-of-step="1" aria-label="One pack more">+</button></div>'
			. '<input type="hidden" name="packs[' . (int) $d['id'] . ']" value="0"></div>';
	}
	$dates = '';
	foreach ( kz_dates() as $k => $v ) {
		$dates .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</option>';
	}
	$times = '';
	foreach ( KZ_TIMES as $k => $v ) {
		$times .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</option>';
	}
	return '<form class="kz-form kz-of" data-kz-order-form novalidate>
		<fieldset class="kz-opt"><legend>1. Your packs <em>' . esc_html( KZ_PACK ) . ' each</em></legend>' . $rows . '</fieldset>
		<fieldset class="kz-opt"><legend>2. Where &amp; when</legend>
			<div class="kz-form__grid">
				<label>Your name<input type="text" name="name" autocomplete="name" required></label>
				<label>Phone number<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required placeholder="07…"></label>
				<label class="kz-form__full">Location (apartment name / house no., area)<input type="text" name="location" autocomplete="street-address" required placeholder="e.g. Royal Court Apts, B4, Kilimani"></label>
				<label>Delivery day<select name="day">' . $dates . '</select></label>
				<label>Time<select name="time">' . $times . '</select></label>
			</div>
		</fieldset>
		<fieldset class="kz-opt"><legend>3. Pay on delivery</legend>
			<div class="kz-pills"><label class="is-on"><input type="radio" name="pay" value="cod" checked><span>M-Pesa or cash on delivery</span></label><label><input type="radio" name="pay" value="bacs"><span>Pay ahead by M-Pesa</span></label></div>
		</fieldset>
		<label class="kz-form__full">Additional notes<input type="text" name="notes" maxlength="300" placeholder="Gate code, call when outside, party on Saturday…"></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="kz-hp" aria-hidden="true">
		<div class="kz-of__sum"><div><span data-kz-of-count>Add at least one pack</span><small>+ ' . esc_html( kz_money( KZ_DELIVERY ) ) . ' delivery anywhere in Nairobi</small></div><strong data-kz-of-total>KSh 0</strong></div>
		<button type="submit" class="wp-element-button kz-form__go" data-kz-of-go>Place my order</button>
		<p class="kz-small" data-kz-of-foot>No account, no card. We call or text to confirm your delivery day.</p>
	</form>';
}
add_shortcode( 'kz_order_form', fn() => kz_order_form() );

add_action( 'rest_api_init', function () {
	register_rest_route( 'kz/v1', '/order', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'kz_rest_order',
	] );
	register_rest_route( 'kz/v1', '/request', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'kz_rest_request',
	] );
} );

/** Spam guard shared by the forms: a hidden field only bots fill in, and 8 sends per 10 minutes per IP. */
function kz_guard( WP_REST_Request $req ) {
	if ( ! empty( $req['website'] ) ) {
		return new WP_Error( 'kz_spam', 'Not sent.', [ 'status' => 400 ] );
	}
	$ip   = 'kz_rl_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' );
	$hits = (int) get_transient( $ip );
	if ( $hits >= 8 ) {
		return new WP_Error( 'kz_slow', 'Too many orders from here. Please try again in a few minutes.', [ 'status' => 429 ] );
	}
	set_transient( $ip, $hits + 1, 10 * MINUTE_IN_SECONDS );
	return true;
}

function kz_rest_order( WP_REST_Request $req ) {
	$ok = kz_guard( $req );
	if ( is_wp_error( $ok ) ) return $ok;
	$f = [];
	foreach ( [ 'name', 'phone', 'location', 'notes', 'day', 'time', 'pay' ] as $k ) {
		$f[ $k ] = mb_substr( trim( sanitize_text_field( (string) $req[ $k ] ) ), 0, 300 );
	}
	foreach ( [ 'name' => 'your name', 'phone' => 'your phone number', 'location' => 'your location' ] as $k => $label ) {
		if ( $f[ $k ] === '' ) return new WP_Error( 'kz_missing', 'Please add ' . $label . '.', [ 'status' => 400 ] );
	}
	if ( strlen( preg_replace( '/\D/', '', $f['phone'] ) ) < 9 ) {
		return new WP_Error( 'kz_phone', 'Please check your phone number.', [ 'status' => 400 ] );
	}
	$lines = [];
	foreach ( (array) $req['packs'] as $id => $qty ) {
		$qty = max( 0, min( 20, (int) $qty ) );
		$p   = wc_get_product( (int) $id );
		if ( $qty && $p && $p->is_purchasable() ) {
			if ( ! $p->is_in_stock() && ! $p->backorders_allowed() ) {
				return new WP_Error( 'kz_out', $p->get_name() . ' is sold out.', [ 'status' => 400 ] );
			}
			$lines[] = [ $p, $qty ];
		}
	}
	if ( ! $lines ) return new WP_Error( 'kz_empty', 'Add at least one pack.', [ 'status' => 400 ] );

	$order = wc_create_order( [ 'created_via' => 'kz-order-form' ] );
	if ( is_wp_error( $order ) ) return new WP_Error( 'kz_save', 'Could not place the order. Please try again.', [ 'status' => 500 ] );
	foreach ( $lines as [ $p, $qty ] ) {
		$order->add_product( $p, $qty );
	}
	[ $first, $last ] = array_pad( explode( ' ', $f['name'], 2 ), 2, '' );
	$address = [ 'first_name' => $first, 'last_name' => $last, 'phone' => $f['phone'], 'address_1' => $f['location'], 'city' => 'Nairobi', 'country' => 'KE' ];
	$order->set_address( $address, 'billing' );
	$order->set_address( $address, 'shipping' );
	$ship = new WC_Order_Item_Shipping();
	$ship->set_method_title( 'Doorstep delivery – Nairobi' );
	$ship->set_method_id( 'flat_rate' );
	$ship->set_total( KZ_DELIVERY );
	$order->add_item( $ship );
	$pay      = $f['pay'] === 'bacs' ? 'bacs' : 'cod';
	$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : [];
	$order->set_payment_method( $gateways[ $pay ] ?? $pay );
	$order->set_payment_method_title( $pay === 'bacs' ? 'Pay now by M-Pesa' : 'Pay on delivery (M-Pesa or cash)' );
	$order->set_customer_note( $f['notes'] );
	$order->update_meta_data( '_wc_other/kz/day', isset( kz_dates()[ $f['day'] ] ) ? $f['day'] : array_key_first( kz_dates() ) );
	$order->update_meta_data( '_wc_other/kz/time', isset( KZ_TIMES[ $f['time'] ] ) ? $f['time'] : 'afternoon' );
	$order->calculate_totals( false );
	$order->set_status( $pay === 'bacs' ? 'on-hold' : 'processing', 'Placed with the quick order form.' );
	$order->save();
	wc_reduce_stock_levels( $order->get_id() );

	return [
		'code'  => kz_order_code( $order ),
		'total' => kz_money( $order->get_total() ),
		'when'  => kz_order_when( $order ),
		'pre'   => (bool) array_filter( $order->get_items(), fn( $i ) => $i->get_meta( 'Backordered' ) ),
	];
}

/* -------------------------------------------------------------------------
 * Requests: BBQ & party orders, Carnivore Club
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	register_post_type( 'kz_request', [
		'label'           => 'Party orders & club',
		'labels'          => [ 'name' => 'Party orders & club', 'singular_name' => 'Request', 'edit_item' => 'Request', 'all_items' => 'Party orders & club' ],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'woocommerce',
		'supports'        => [ 'title', 'editor' ],
		'capability_type' => 'post',
		'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap'    => true,
	] );
} );

// type => [ title, reference letter ].
const KZ_REQUEST_TYPES = [
	'party' => [ 'BBQ / party order', 'P' ],
	'club'  => [ 'Carnivore Club sign-up', 'C' ],
];
// What each form sends: field => label. Required fields end in "*".
const KZ_REQUEST_FIELDS = [
	'party' => [ 'occasion*' => 'Occasion', 'date*' => 'Date', 'guests*' => 'Guests', 'packs' => 'Packs (rough)', 'flavours' => 'Flavours', 'name*' => 'Name', 'phone*' => 'Phone', 'location' => 'Location', 'notes' => 'Notes' ],
	'club'  => [ 'name*' => 'Name', 'contact*' => 'Phone or email' ],
];

add_filter( 'manage_kz_request_posts_columns', fn( $c ) => [ 'cb' => $c['cb'], 'title' => 'Request', 'kz_type' => 'Type', 'kz_contact' => 'Contact', 'date' => 'Received' ] );
add_action( 'manage_kz_request_posts_custom_column', function ( $col, $id ) {
	if ( $col === 'kz_type' ) echo esc_html( KZ_REQUEST_TYPES[ get_post_meta( $id, '_kz_type', true ) ][0] ?? '' );
	if ( $col === 'kz_contact' ) {
		$c      = (string) get_post_meta( $id, '_kz_contact', true );
		$digits = preg_replace( '/\D/', '', $c );
		echo strlen( $digits ) >= 9 && ! str_contains( $c, '@' ) ? '<a href="tel:' . esc_attr( $digits ) . '">' . esc_html( $c ) . '</a>' : esc_html( $c );
	}
}, 10, 2 );

function kz_rest_request( WP_REST_Request $req ) {
	$type = sanitize_key( $req['type'] );
	if ( ! isset( KZ_REQUEST_FIELDS[ $type ] ) ) {
		return new WP_Error( 'kz_type', 'Unknown request.', [ 'status' => 400 ] );
	}
	$ok = kz_guard( $req );
	if ( is_wp_error( $ok ) ) return $ok;
	$data = [];
	$rows = [];
	foreach ( KZ_REQUEST_FIELDS[ $type ] as $key => $label ) {
		$field = rtrim( $key, '*' );
		$value = trim( sanitize_text_field( (string) $req[ $field ] ) );
		if ( $field === 'date' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			$value = wp_date( 'D j M Y', strtotime( $value . ' 12:00' ) );
		}
		if ( $value === '' && str_ends_with( $key, '*' ) ) {
			return new WP_Error( 'kz_missing', 'Please fill in: ' . $label . '.', [ 'status' => 400 ] );
		}
		$data[ $field ] = mb_substr( $value, 0, 600 );
		if ( $data[ $field ] !== '' ) $rows[] = $label . ': ' . $data[ $field ];
	}
	[ $title, $letter ] = KZ_REQUEST_TYPES[ $type ];
	$id = wp_insert_post( [ 'post_type' => 'kz_request', 'post_status' => 'publish', 'post_title' => $title . ' – ' . $data['name'], 'post_content' => implode( "\n", $rows ) ] );
	if ( ! $id || is_wp_error( $id ) ) {
		return new WP_Error( 'kz_save', 'Could not send. Please try again.', [ 'status' => 500 ] );
	}
	$ref = 'PB-' . $letter . $id;
	update_post_meta( $id, '_kz_type', $type );
	update_post_meta( $id, '_kz_contact', $data['phone'] ?? $data['contact'] ?? '' );
	wp_update_post( [ 'ID' => $id, 'post_title' => $title . ' – ' . $data['name'] . ' (' . $ref . ')' ] );
	wp_mail( get_option( 'admin_email' ), 'New ' . strtolower( $title ) . ' ' . $ref, implode( "\n", $rows ) );
	return [ 'ref' => $ref ];
}

add_shortcode( 'kz_party_form', function () {
	return '<form class="kz-form" data-kz-request="party" novalidate>
		<div class="kz-form__grid">
			<label>Occasion<select name="occasion" required><option>Weekend nyama choma</option><option>Birthday</option><option>Office party / team lunch</option><option>Wedding or ruracio</option><option>Something else</option></select></label>
			<label>Date<input type="date" name="date" required min="' . esc_attr( wp_date( 'Y-m-d' ) ) . '"></label>
			<label>Guests<input type="number" name="guests" min="5" max="500" value="20" inputmode="numeric" required></label>
			<label>Packs (rough)<select name="packs"><option>3 – 5 packs</option><option selected>6 – 10 packs</option><option>11 – 20 packs</option><option>20+ packs</option><option>Not sure, advise me</option></select></label>
			<label>Flavours<select name="flavours"><option>A mix of all three</option><option>Mostly Chilli Honey Heat</option><option>Mostly Classic</option><option>Mostly Cheese &amp; Onion</option></select></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone number<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
			<label>Location<input type="text" name="location" placeholder="Area / venue"></label>
		</div>
		<label class="kz-form__full">Anything else?<input type="text" name="notes" maxlength="400" placeholder="Grilling on site? Need them on a certain day?"></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="kz-hp" aria-hidden="true">
		<button type="submit" class="wp-element-button kz-form__go">Reserve packs for my party</button>
		<p class="kz-small">We reply with what is free in the coming batches and a total. Bigger orders need a few days\' notice.</p>
	</form>';
} );

add_shortcode( 'kz_club_form', function () {
	return '<form class="kz-club" data-kz-request="club" novalidate>
		<label><span class="screen-reader-text">Your name</span><input type="text" name="name" placeholder="Your name" autocomplete="name" required></label>
		<label><span class="screen-reader-text">Phone number or email</span><input type="text" name="contact" placeholder="Phone number or email" required></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="kz-hp" aria-hidden="true">
		<button type="submit" class="wp-element-button">Join the club</button>
	</form>';
} );

/* -------------------------------------------------------------------------
 * Reviews (his "Sausage Reviews" highlight) and recipes (his reels)
 * ---------------------------------------------------------------------- */

const KZ_REVIEWS = [
	[ 'It\'s spicy, it\'s a work of art, I\'m in culinary heaven.', '@ninas_kitchen.ke', 'Chilli Honey Heat', 'hlf-ninas' ],
	[ 'Theeeese "Chilli Honey Heat" flavour are a 10/10. Give them your monies.', '@mi.ni.ndech', 'Chilli Honey Heat', 'hlf-mini' ],
	[ 'Perfect size and they are 💯 nyama. Perfect for guys doing high protein meals.', '@mi.ni.ndech', 'Pan-fried at home', '' ],
	[ 'These sausages are addictive. Also a really good add-on to salads.', '@africanbarb', 'Sausage salad', '' ],
];

add_shortcode( 'kz_reviews', function () {
	$h = '<div class="kz-reviews">';
	foreach ( KZ_REVIEWS as [ $text, $who, $what ] ) {
		$h .= '<figure class="kz-review"><span class="kz-quote" aria-hidden="true">“</span><blockquote>' . esc_html( $text ) . '</blockquote><figcaption><strong>' . esc_html( $who ) . '</strong><span>' . esc_html( $what ) . ' · shared on Instagram</span></figcaption></figure>';
	}
	return $h . '</div><p class="kz-reviews__src">From customers\' own Instagram stories, saved in the <a href="' . esc_url( KZ_IG ) . '" target="_blank" rel="noopener">"Sausage Reviews" highlight on @kings_eatz</a>.</p>';
} );

require __DIR__ . '/recipes.php';

add_shortcode( 'kz_recipes', function ( $atts ) {
	$atts = shortcode_atts( [ 'limit' => 0 ], $atts );
	$list = kz_recipes();
	if ( $atts['limit'] ) $list = array_slice( $list, 0, (int) $atts['limit'] );
	$uri = get_stylesheet_directory_uri() . '/assets/photos/';
	$h   = '<div class="kz-recipes">';
	foreach ( $list as $r ) {
		$h .= '<article class="kz-recipe" id="' . esc_attr( $r['slug'] ) . '"><img src="' . esc_url( $uri . 'recipe-' . $r['slug'] . '.webp' ) . '" alt="' . esc_attr( $r['name'] ) . '" width="720" height="720" loading="lazy">'
			. '<div class="kz-recipe__body"><p class="kz-eyebrow">' . esc_html( $r['tag'] ) . '</p><h3>' . esc_html( $r['name'] ) . '</h3><p>' . esc_html( $r['intro'] ) . '</p>'
			. '<details class="kz-recipe__more"><summary>Ingredients &amp; method</summary><div><h4>Ingredients</h4>';
		foreach ( $r['ingredients'] as $group => $items ) {
			$h .= ( is_string( $group ) ? '<p class="kz-recipe__group">' . esc_html( $group ) . '</p>' : '' ) . '<ul>' . implode( '', array_map( fn( $i ) => '<li>' . esc_html( $i ) . '</li>', $items ) ) . '</ul>';
		}
		if ( $r['method'] ) {
			$h .= '<h4>Method</h4><ol>' . implode( '', array_map( fn( $s ) => '<li>' . esc_html( $s ) . '</li>', $r['method'] ) ) . '</ol>';
		}
		$h .= '</div></details><div class="kz-recipe__links"><a class="kz-link" href="' . esc_url( $r['reel'] ) . '" target="_blank" rel="noopener">▶ Watch Elvis make it</a><a class="kz-link" href="/order/#box" data-kz-box-link>Get the sausages →</a></div></div></article>';
	}
	return $h . '</div>';
} );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_product_single_add_to_cart_text', function ( $text, $product = null ) {
	return $product instanceof WC_Product && $product->managing_stock() && $product->get_stock_quantity() <= 0 ? 'Pre-order for the next batch' : 'Add to my box';
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_text', fn( $t, $p ) => $p && $p->is_purchasable() ? 'Add to box' : $t, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	return $product->is_type( 'simple' ) ? kz_batch_status( $product )['label'] : $text;
}, 10, 2 );
add_filter( 'woocommerce_get_availability_class', function ( $class, $product ) {
	return $product->is_type( 'simple' ) ? $class . ' kz-batch kz-batch--' . kz_batch_status( $product )['state'] : $class;
}, 10, 2 );

add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id    = $product->get_id();
	$heat  = (int) get_post_meta( $id, '_kz_heat', true );
	$badge = get_post_meta( $id, '_kz_badge', true );
	echo '<div class="kz-tags">' . ( $badge ? '<span class="kz-tag">' . esc_html( $badge ) . '</span>' : '' ) . '<span class="kz-tag kz-tag--line">' . esc_html( KZ_PACK ) . '</span><span class="kz-tag kz-tag--line">' . kz_flames( $heat ) . ' ' . esc_html( KZ_HEAT[ $heat ] ?? '' ) . '</span></div>'; // phpcs:ignore
	$flavour = get_post_meta( $id, '_kz_flavour', true );
	if ( $flavour ) echo '<p class="kz-pdp-flavour"><strong>How it tastes:</strong> ' . esc_html( $flavour ) . '</p>';
} );

add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id = $product->get_id();
	echo '<button type="button" class="kz-form-btn" data-kz-order="' . (int) $id . '">' . KZ_FORM_ICON . 'Or order with the quick form</button>'; // phpcs:ignore
	$reel = get_post_meta( $id, '_kz_reel', true );
	if ( $reel ) {
		echo '<a class="kz-reel" href="' . esc_url( $reel ) . '" target="_blank" rel="noopener"><span aria-hidden="true">▶</span>Watch how they\'re made on Instagram</a>';
	}
	echo kz_promise(); // phpcs:ignore
} );

function kz_promise() {
	return '<div class="kz-promise"><div><span aria-hidden="true">🥩</span><p><strong>100% meat, no fillers</strong>Minced, spiced and stuffed by hand. Nothing to bulk it out.</p></div><div><span aria-hidden="true">🔥</span><p><strong>Real smoke</strong>Smoked low and slow in our own wooden smokehouse.</p></div><div><span aria-hidden="true">🛵</span><p><strong>' . esc_html( kz_money( KZ_DELIVERY ) ) . ' delivery, anywhere in Nairobi</strong>Vacuum-sealed and brought to your door. Pay on delivery.</p></div></div>';
}

add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product instanceof WC_Product ) return $tabs;
	$id = $product->get_id();
	if ( isset( $tabs['description'] ) ) $tabs['description']['title'] = 'About this pack';
	$pairs = kz_lines( $id, 'pairs' );
	$tabs['kz_cook'] = [
		'title'    => 'How to cook them',
		'priority' => 5,
		'callback' => function () use ( $pairs ) {
			echo kz_cook_guide(); // phpcs:ignore
			if ( $pairs ) echo '<h3>Great with</h3><ul class="kz-checks-list">' . implode( '', array_map( fn( $s ) => '<li>' . esc_html( $s ) . '</li>', $pairs ) ) . '</ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

function kz_cook_guide() {
	return '<div class="kz-cook"><div><h3>🔥 On the grill</h3><p>Over medium coals, turning often, until browned all over and hot right through. The honey in Chilli Honey Heat caramelises fast, so keep them moving.</p></div><div><h3>🍳 In the pan</h3><p>Only a little oil: "the sausages are juicy and will produce their own fat" (@mi.ni.ndech). Medium heat, turn until golden.</p></div><div><h3>💨 Air fryer or oven</h3><p>Until nicely browned and cooked through, as Elvis does for his hotdogs. Slice and add to stews, rice or salads.</p></div><p class="kz-small">Keep the sealed packs in the fridge and use within a few days, or freeze. Thaw in the fridge before cooking. (PLACEHOLDER: confirm the keeping times with Elvis.)</p></div>';
}

add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

/* -------------------------------------------------------------------------
 * Dialogs
 * ---------------------------------------------------------------------- */

add_action( 'wp_footer', function () {
	echo '<dialog id="kz-pack" class="kz-dialog kz-pack" aria-label="Pack details"><form method="dialog"><button class="kz-dialog__close" aria-label="Close">×</button></form><div data-kz-pack-body></div></dialog>';
	if ( ! is_checkout() ) {
		echo '<dialog id="kz-order" class="kz-dialog kz-dialog--form" aria-labelledby="kz-order-title"><form method="dialog"><button class="kz-dialog__close" aria-label="Close">×</button></form><p class="kz-eyebrow">Quick order form</p><h2 id="kz-order-title">Order in under a minute</h2>' . kz_order_form() . '</dialog>'; // phpcs:ignore
	}
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, confirmation
 * ---------------------------------------------------------------------- */

function kz_cart_note_html() {
	$b = kz_next_batch();
	return '<div class="kz-cart-note"><strong>Next:</strong> doorstep delivery anywhere in Nairobi for ' . esc_html( kz_money( KZ_DELIVERY ) ) . '. Pay on delivery by M-Pesa or cash. Pre-ordered packs come from the ' . esc_html( $b['label'] ) . ' batch.</div>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => kz_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/mini-cart-contents', fn( $c ) => preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', kz_cart_note_html() . '$1', $c, 1 ) );

add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Place my order' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Checkout' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your box' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Checkout' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View box' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact', 'Your order confirmation goes here.' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Where should we deliver?', 'Apartment name and house number, and a landmark for the rider.' ],
		'woocommerce/checkout-shipping-address-block'       => [ 'Where should we deliver?', 'Apartment name and house number, and a landmark for the rider.' ],
		'woocommerce/checkout-shipping-methods-block'       => [ 'Delivery', 'One price anywhere in Nairobi.' ],
		'woocommerce/checkout-additional-information-block' => [ 'When?', 'Pick a delivery day and time.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is charged online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	// "When?" comes before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) return;
	woocommerce_register_additional_checkout_field( [
		'id'       => 'kz/day',
		'label'    => 'Delivery day',
		'location' => 'order',
		'type'     => 'select',
		'required' => true,
		'options'  => array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( kz_dates() ), kz_dates() ),
	] );
	woocommerce_register_additional_checkout_field( [
		'id'       => 'kz/time',
		'label'    => 'Time',
		'location' => 'order',
		'type'     => 'select',
		'required' => true,
		'options'  => array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( KZ_TIMES ), KZ_TIMES ),
	] );
} );

function kz_order_code( WC_Order $order ) {
	return 'PB-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function kz_order_when( WC_Order $order ) {
	$day  = (string) $order->get_meta( '_wc_other/kz/day' );
	$time = (string) $order->get_meta( '_wc_other/kz/time' );
	$d    = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ? wp_date( 'D j M', strtotime( $day . ' 12:00' ) ) : $day;
	return trim( $d . ( $time ? ', ' . strtolower( strtok( KZ_TIMES[ $time ] ?? $time, ' ' ) ) : '' ), ', ' );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	return $content . kz_thanks_html( kz_order_code( $order ), kz_order_when( $order ) );
} );
function kz_thanks_html( $code, $when ) {
	return '<div class="kz-thanks"><p class="kz-thanks__code">Order number <strong>' . esc_html( $code ) . '</strong></p><p class="kz-thanks__when">Doorstep delivery · ' . esc_html( $when ) . '</p><ol><li>We call or text the number you gave to confirm your delivery day.</li><li>Your packs come vacuum-sealed from the current batch (pre-orders from the next one).</li><li>Pay the rider by M-Pesa or cash, then fire up the jiko.</li></ol><p>While you wait: <a href="/recipes/">six ways Elvis cooks them →</a></p></div>';
}
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order number:</strong> ' . esc_html( kz_order_code( $order ) ) . '<br><strong>Delivery:</strong> ' . esc_html( kz_order_when( $order ) ) . '</p>';
} );

/* -------------------------------------------------------------------------
 * Admin: product extras, batch drops
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_kz_tagline', 'label' => 'Tagline', 'description' => 'e.g. "Sweet, then the kick"', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_kz_emoji', 'label' => 'Emoji', 'description' => 'e.g. 🌶️🍯', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_kz_badge', 'label' => 'Badge', 'description' => 'Short label on the photo, e.g. "Customer favourite".', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_kz_heat', 'label' => 'Heat', 'options' => array_map( 'strval', KZ_HEAT ) ] );
	woocommerce_wp_textarea_input( [ 'id' => '_kz_flavour', 'label' => 'How it tastes', 'rows' => 2 ] );
	woocommerce_wp_textarea_input( [ 'id' => '_kz_pairs', 'label' => 'Great with', 'rows' => 3, 'description' => 'One per line.' ] );
	woocommerce_wp_text_input( [ 'id' => '_kz_reel', 'label' => 'Instagram reel link' ] );
	echo '<p class="form-field"><em>Batch stock: Inventory → Stock quantity is the number of packs in this batch. At 0 the pack switches to pre-orders for the next batch; set "Allow backorders" to "Do not allow" to stop taking orders.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_kz_tagline', '_kz_emoji', '_kz_badge', '_kz_heat' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) $product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
	}
	foreach ( [ '_kz_flavour', '_kz_pairs' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) $product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
	}
	if ( isset( $_POST['_kz_reel'] ) ) $product->update_meta_data( '_kz_reel', esc_url_raw( wp_unslash( $_POST['_kz_reel'] ) ) ); // phpcs:ignore
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Batch drops', 'Batch drops', 'manage_woocommerce', 'kz-batch', function () {
		if ( isset( $_POST['kz_batch_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['kz_batch_nonce'] ), 'kz_batch' ) ) {
			update_option( 'kz_batch_day', (string) max( 1, min( 7, (int) ( $_POST['kz_batch_day'] ?? 5 ) ) ) );
			update_option( 'kz_batch_note', sanitize_text_field( wp_unslash( $_POST['kz_batch_note'] ?? '' ) ) );
			$stocks = (array) ( $_POST['kz_stock'] ?? [] ); // phpcs:ignore
			foreach ( $stocks as $pid => $qty ) {
				$p = wc_get_product( (int) $pid );
				// Only what was changed: a negative count is pre-orders still owed from the next batch.
				if ( $p && $qty !== '' && (int) $qty !== (int) $p->get_stock_quantity() ) wc_update_product_stock( $p, (int) $qty );
			}
			echo '<div class="notice notice-success"><p>Saved.</p></div>';
		}
		$day = (int) get_option( 'kz_batch_day', 5 );
		echo '<div class="wrap"><h1>Batch drops</h1><p>The shop shows what is left of each pack in the current batch, and takes pre-orders for the next batch day once a pack hits 0. Start a new batch by entering how many packs you made, minus any already pre-ordered (shown as a negative number).</p><form method="post">';
		wp_nonce_field( 'kz_batch', 'kz_batch_nonce' );
		echo '<table class="form-table"><tr><th>Batch day</th><td><select name="kz_batch_day">';
		foreach ( KZ_DAYS as $n => $label ) echo '<option value="' . $n . '"' . selected( $n, $day, false ) . '>' . esc_html( $label ) . '</option>';
		echo '</select><p class="description">Next batch shown on the site: <strong>' . esc_html( kz_next_batch()['label'] ) . '</strong></p></td></tr>';
		echo '<tr><th>Batch note</th><td><input class="regular-text" name="kz_batch_note" value="' . esc_attr( get_option( 'kz_batch_note', '' ) ) . '"></td></tr>';
		foreach ( kz_products() as $d ) {
			$qty = (int) wc_get_product( $d['id'] )->get_stock_quantity();
			echo '<tr><th>' . esc_html( $d['name'] ) . '</th><td><input type="number" name="kz_stock[' . (int) $d['id'] . ']" value="' . esc_attr( (string) $qty ) . '" class="small-text"> packs left <span class="description">(' . esc_html( $d['batch']['label'] ) . ( $qty < 0 ? '; ' . abs( $qty ) . ' pre-ordered' : '' ) . ')</span></td></tr>';
		}
		echo '</table>';
		submit_button( 'Save batch' );
		echo '</form></div>';
	} );
}, 60 );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['state']     = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'label' => 'Apartment / estate & street' ];
	$locale['KE']['address_2'] = [ 'label' => 'House number, gate or landmark', 'required' => true ];
	$locale['KE']['city']      = [ 'label' => 'Area (e.g. Kilimani, Westlands)' ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );

add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) return $text;
	return [
		'Related products'  => 'Try these too',
		'Continue shopping' => 'Back to the sausages',
		'Shipping:'         => 'Delivery:',
		'Shipping address'  => 'Delivery address',
		'Available on backorder' => 'Pre-order: from the next batch',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', fn( $text, $single, $plural, $number, $domain ) => $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your box.' : $text, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

add_action( 'wp_head', function () {
	if ( has_site_icon() ) return;
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#18181B\">\n";
} );

// Shortcode blocks: run the shortcode as is (the block's automatic paragraphs break the grids).
add_filter( 'pre_render_block', fn( $pre, $block ) => ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre, 10, 2 );
// Shortcodes inside custom HTML blocks on the templates.
add_filter( 'render_block_core/html', fn( $c ) => str_contains( $c, '[kz_' ) ? do_shortcode( $c ) : $c );

// Templates use root-relative links ("/order/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) return $content;
	return preg_replace( '#\b(href|src|action|poster)="/(?!/)#', '$1="' . $home, $content );
} );
